from flask import Flask, render_template, request
from sklearn.externals import joblib
import os

app = Flask(__name__, static_url_path='/static/')


@app.route('/') #***********
def form():
    return render_template('indexAKN4.html')


@app.route('/score_flight', methods=['POST', 'GET']) #***********
def score_flight():
    # get the parameters
    SCHEDULED_DEPARTURE = float(request.form['SCHEDULED_DEPARTURE'])
    SCHEDULED_ARRIVAL = float(request.form['SCHEDULED_ARRIVAL'])
    SCHEDULED_TIME = float(request.form['SCHEDULED_TIME'])
    DAY_OF_WEEK = float(request.form['DAY_OF_WEEK'])
    MONTH = float(request.form['MONTH'])
    AA = float(request.form['AA'])
    AS= float(request.form['AS'])
    B6= float(request.form['B6'])
    DL= float(request.form['DL'])
    EV= float(request.form['EV'])
    F9= float(request.form['F9'])
    HA= float(request.form['HA'])
    MQ= float(request.form['MQ'])
    NK= float(request.form['NK'])
    OO= float(request.form['OO'])
    UA= float(request.form['UA'])
    US= float(request.form['US'])
    VX= float(request.form['VX'])
    WN= float(request.form['WN'])

    # load the model and predict
    model = joblib.load('model/cancellationrf.pkl')
    cancprob=model.predict_proba([[SCHEDULED_DEPARTURE, SCHEDULED_ARRIVAL, SCHEDULED_TIME, DAY_OF_WEEK, MONTH,AA,AS,B6,DL,EV,F9,HA,MQ,NK,OO,UA,US,VX,WN]])
    SCORED_FLIGHT=100-100*cancprob.round(2)[0][0]
    

    return render_template('resultsAKN2.html',
                           SCHEDULED_DEPARTURE=int(SCHEDULED_DEPARTURE),
                           SCHEDULED_ARRIVAL=int(SCHEDULED_ARRIVAL),
                           SCHEDULED_TIME=int(SCHEDULED_TIME),
                           DAY_OF_WEEK=int(DAY_OF_WEEK),
                           MONTH=int(MONTH),
                           AA=int(AA),
                           AS=int(AS),
                           B6=int(B6),
                           DL=int(DL),
                           EV=int(EV),
                           F9=int(F9),
                           HA=int(HA),
                           MQ=int(MQ),
                           NK=int(NK),
                           OO=int(OO),
                           UA=int(UA),
                           US=int(US),
                           VX=int(VX),
                           WN=int(WN),
                           SCORED_FLIGHT="{:,}".format(SCORED_FLIGHT)
                           )


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
